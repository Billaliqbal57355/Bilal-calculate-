plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.example.offlinemeterreader"; compileSdk = 35; defaultConfig { applicationId = "com.example.offlinemeterreader"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" } }
dependencies { implementation("com.google.mlkit:text-recognition:16.0.1"); implementation("androidx.activity:activity-ktx:1.9.3"); implementation("androidx.appcompat:appcompat:1.7.0"); implementation("com.google.android.material:material:1.12.0") }
