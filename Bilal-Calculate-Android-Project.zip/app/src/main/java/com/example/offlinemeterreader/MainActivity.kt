package com.example.offlinemeterreader

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var rawText: TextView
    private lateinit var correctedInput: EditText
    private lateinit var converted: TextView
    private var currentValue: java.math.BigDecimal? = null
    private val ocr by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let(::scan)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Bilal Calculate"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Choose a clear photo. Underscores in numbers are always converted to decimal points."
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "Choose photo"
            setOnClickListener { picker.launch("image/*") }
        })
        status = TextView(this).apply { text = "Ready"; textSize = 16f }
        root.addView(status)
        root.addView(TextView(this).apply { text = "Recognized text"; textSize = 18f })
        rawText = TextView(this).apply { text = "No image selected."; textSize = 16f }
        root.addView(rawText)
        root.addView(TextView(this).apply {
            text = "Edit number if needed"
            textSize = 18f
        })
        correctedInput = EditText(this).apply {
            hint = "Example: 2_560"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        root.addView(correctedInput)
        root.addView(Button(this).apply {
            text = "Convert value"
            setOnClickListener { showConverted(correctedInput.text.toString()) }
        })
        converted = TextView(this).apply {
            text = "Converted value will appear here."
            textSize = 28f
        }
        root.addView(converted)
        val adjustRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
        }
        adjustRow.addView(Button(this).apply {
            text = "+"
            textSize = 24f
            setOnClickListener { adjustValue(1) }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        adjustRow.addView(Button(this).apply {
            text = "−"
            textSize = 24f
            setOnClickListener { adjustValue(-1) }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(adjustRow)
        root.addView(Button(this).apply {
            text = "Copy result"
            setOnClickListener {
                val value = converted.text.toString()
                if (value.isNotBlank() && !value.startsWith("Converted")) {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Converted value", value))
                    Toast.makeText(this@MainActivity, "Copied", Toast.LENGTH_SHORT).show()
                }
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun scan(uri: Uri) {
        status.text = "Recognizing on this device…"
        try {
            val bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri))
            ocr.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { vision ->
                    val text = vision.text
                    rawText.text = text.ifBlank { "No text found." }
                    // Capture number-like sequences, including underscore separators.
                    val matches = Regex("""\d+(?:[_., ]\d+)+|\d+""")
                        .findAll(text).map { it.value }.distinct().toList()
                    if (matches.isNotEmpty()) {
                        correctedInput.setText(matches.first())
                        showConverted(matches.first())
                        status.text = "Done. Verify the reading before use."
                    } else {
                        status.text = "No numbers detected. You can enter one manually."
                    }
                }
                .addOnFailureListener { status.text = "Recognition failed. Try a clearer photo." }
        } catch (_: Exception) {
            status.text = "Could not open image. Choose another photo."
        }
    }

    private fun showConverted(input: String) {
        val value = input.trim().replace('_', '.')
        currentValue = try { value.toBigDecimal() } catch (_: Exception) { null }
        converted.text = currentValue?.toPlainString() ?: if (value.isEmpty()) "Enter a number first." else "Invalid number"
    }

    private fun adjustValue(amount: Int) {
        val value = currentValue ?: run {
            Toast.makeText(this, "Convert a number first.", Toast.LENGTH_SHORT).show()
            return
        }
        currentValue = value.add(java.math.BigDecimal.valueOf(amount.toLong()))
        converted.text = currentValue!!.toPlainString()
    }

    override fun onDestroy() {
        ocr.close()
        super.onDestroy()
    }
}
