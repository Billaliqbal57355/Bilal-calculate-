# Offline Meter Reader
Android Studio starter project. Select a photo; on-device ML Kit OCR extracts text and converts underscore separators to decimal points (2_560 -> 2.560). Open the folder in Android Studio and build an APK. Initial dependency download/build requires internet; recognition works offline after installation. Verify readings before relying on them.
